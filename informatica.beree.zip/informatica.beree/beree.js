document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("loginForm");

  // Usuarios válidos
  const usuarios = [
    { usuario: "BereeyJuniorH", password: "777" },
    { usuario: "Persona1", password: "12345" },
    { usuario: "Persona2", password: "67890" }
  ];

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    const usuarioValido = usuarios.find(u => u.usuario === username && u.password === password);

    if (usuarioValido) {
      // Guardar el usuario ingresado
      localStorage.setItem("usuarioActual", usuarioValido.usuario);

      // Mostrar toast
      showToast("Usuario logeado ✅");

      // Redirigir a la página de bienvenida después de 1.5s
      setTimeout(() => {
        window.location.href = "bienvenido.html";
      }, 1500);
    } else {
      alert("Credenciales incorrectas");
    }
  });
});

function showToast(message) {
  const toast = document.createElement("div");
  toast.textContent = message;
  toast.style.position = "fixed";
  toast.style.bottom = "20px";
  toast.style.right = "20px";
  toast.style.background = "#2563eb";
  toast.style.color = "#fff";
  toast.style.padding = "12px 20px";
  toast.style.borderRadius = "8px";
  toast.style.boxShadow = "0 4px 8px rgba(0,0,0,0.2)";
  toast.style.fontSize = "1rem";
  toast.style.zIndex = "9999";
  toast.style.opacity = "0";
  toast.style.transition = "opacity 0.5s ease";

  document.body.appendChild(toast);

  setTimeout(() => { toast.style.opacity = "1"; }, 100);
  setTimeout(() => {
    toast.style.opacity = "0";
    setTimeout(() => { toast.remove(); }, 500);
  }, 3000);
}