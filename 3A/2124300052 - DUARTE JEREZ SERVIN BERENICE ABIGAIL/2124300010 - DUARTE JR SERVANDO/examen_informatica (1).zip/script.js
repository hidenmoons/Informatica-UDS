document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();

    if (username === 'admin' && password === '1234') {
        showToast("Usuario logueado", false, true); // true = redirigir
    } else {
        showToast("Credenciales incorrectas", true, false);
    }
});

function showToast(message, isError, redirect = false) {
    const toast = document.getElementById('toast');
    toast.textContent = message;

    // Reset clases
    toast.className = '';
    toast.classList.add('show');

    if (isError) {
        toast.classList.add('error');
    }

    setTimeout(function() {
        toast.className = '';
        if (redirect) {
            // Redirige a bn.html después del toast
            window.location.href = 'bn.html';
        }
    }, 3000); // espera a que termine el toast
}
